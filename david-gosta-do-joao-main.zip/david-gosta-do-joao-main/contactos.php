<?php
session_start();
require "db.php";

$enviado = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email    = escapeshellarg($_POST['email']);
    $assunto  = escapeshellarg($_POST['assunto'] ?? '');
    $mensagem = escapeshellarg($_POST['mensagem'] ?? '');

    // Passa email, assunto e mensagem para o Python
    $comando = "python Email.py $email $assunto $mensagem 2>&1";
    $output  = shell_exec($comando);

    $enviado = true;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Formulário de Contacto</title>
    <link rel="stylesheet" href="CSS.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="contact-page">

<div class="container contact-container">
    <?php if (isset($_SESSION['user'])): ?>
        <div class="contact-user">
            <span class="user-badge">
                Olá, <?php echo htmlspecialchars($_SESSION['user']['username']); ?>
            </span>
        </div>
    <?php endif; ?>

    <h2>Envie-nos uma mensagem</h2>
    <form method="POST">
        <div class="form-group">
            <label>Nome</label>
            <input type="text" name="nome" placeholder="O seu nome" required class="form-control">
        </div>
        
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="seu.email@exemplo.com" required class="form-control">
        </div>
        
        <div class="form-group">
            <label>Assunto</label>
            <input type="text" name="assunto" placeholder="Assunto da mensagem" class="form-control">
        </div>
        
        <div class="form-group">
            <label>Mensagem</label>
            <textarea name="mensagem" rows="5" placeholder="Escreva a sua mensagem aqui..." class="form-control"></textarea>
        </div>
        
        <button type="submit" class="btn-primary">
            <i class="fa-regular fa-paper-plane"></i> Enviar Mensagem
        </button>
    </form>
</div>

<?php if ($enviado): ?>
<script>
    alert("Mensagem enviada com sucesso!");
</script>
<?php endif; ?>

</body>
</html>