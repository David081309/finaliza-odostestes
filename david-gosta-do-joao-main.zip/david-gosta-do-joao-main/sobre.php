html
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ZeroLixo</title>

<link rel="stylesheet" href="CSS.css">

<style>
* {
  box-sizing: border-box;
}

body{
  font-family: Verdana;
  margin:0;
}

.menu {
  float: left;
  width: 20%;
}

.menuitem {
  padding: 8px;
  margin-top: 7px;
  border-bottom: 1px solid #f1f1f1;
  cursor:pointer;
}

.main {
  float: left;
  width: 60%;
  padding: 0 20px;
  overflow: hidden;
}

.right {
  background-color: lightblue;
  float: left;
  width: 20%;
  padding: 10px 15px;
  margin-top: 7px;
}

@media only screen and (max-width:800px) {

  .main {
    width: 80%;
    padding: 0;
  }

  .right {
    width: 100%;
  }
}

@media only screen and (max-width:500px) {

  .menu, .main, .right {
    width: 100%;
  }
}


footer{
  background-color:#f1f1f1;
  text-align:center;
  padding:10px;
  margin-top:7px;
  font-size:12px;
}
</style>
</head>


<body>

<div style="background-color:#f1f1f1;padding:15px;">
  <h1>ZeroLixo</h1>
  <h3>Reciclagem e Sustentabilidade em Lisboa</h3>
</div>


<div style="overflow:auto">

 
  <div class="menu">
    <div class="menuitem">Início</div>
    <div class="menuitem">Pontos de Reciclagem</div>
    <div class="menuitem">Informações</div>
    <div class="menuitem">Galeria</div>

  </div>


 
  <div class="main">

    <h2>Sobre Nós</h2>

    <p>
    O <b>ZeroLixo</b> é um website que mostra os pontos de recolha e reciclagem em Lisboa,
    facilitando aos cidadãos para saber onde depositar corretamente os resíduos.
    O objetivo é promover a reciclagem e contribuir para uma cidade mais limpa e organizada.
    </p>

    <h2>Produção de Resíduos em Portugal</h2>

    <p>O gráfico abaixo mostra a produção de resíduos por pessoa em Portugal.</p>

    
    <img src="imagem/grafico.jpg"
           type="application/pdf"
           width="100%"
           height="500px">

  </div>



  <div class="right">

    <h2>Contacto</h2>
    <p>Email: zerolixo@gmail.com</p>

    <h2>Objetivo</h2>
    <p>Incentivar a reciclagem e ajudar os cidadãos a encontrar pontos de recolha de resíduos.</p>

  </div>

</div>



<footer>
<p>&copy; 2026 ZeroLixo. Todos os direitos reservados.</p>
</footer>


</body>
</html>

