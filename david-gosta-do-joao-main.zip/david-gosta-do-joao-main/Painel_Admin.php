﻿<?php
session_start();
require "db.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: Login.php");
    exit();
}

$erro = "";
$sucesso = "";

/* ===== ADICIONAR NOVO PONTO ===== */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['adicionar_ponto'])) {
    $latitude  = trim($_POST['latitude'] ?? '');
    $longitude = trim($_POST['longitude'] ?? '');
    $localNome = trim($_POST['local_nome'] ?? '');
    $tipoEquipamento = trim($_POST['top_mod_1'] ?? '');

    if ($latitude === "" || $longitude === "" || $localNome === "" || $tipoEquipamento === "") {
        $erro = "Preencha todos os campos do ponto.";
    } else {
        try {
            /* 1) Guardar na base de dados */
            $stmt = $pdo->prepare("
                INSERT INTO pontos_recolha (latitude, longitude, local_nome)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                (float)$latitude,
                (float)$longitude,
                $localNome
            ]);

            /* 2) Atualizar o pontos.json mantendo a estrutura original */
            $jsonPath = __DIR__ . '/pontos.json';

            $geo = [];
            if (file_exists($jsonPath)) {
                $geo = json_decode(file_get_contents($jsonPath), true);
            }

            if (!isset($geo['type'])) {
                $geo['type'] = 'FeatureCollection';
            }

            if (!isset($geo['crs'])) {
                $geo['crs'] = [
                    "type" => "name",
                    "properties" => [
                        "name" => "EPSG:4326"
                    ]
                ];
            }

            if (!isset($geo['features']) || !is_array($geo['features'])) {
                $geo['features'] = [];
            }

            $novoId = count($geo['features']) + 1;

            $geo['features'][] = [
                "type" => "Feature",
                "id" => $novoId,
                "geometry" => [
                    "type" => "Point",
                    "coordinates" => [
                        (float)$longitude,
                        (float)$latitude
                    ]
                ],
                "properties" => [
                    "OBJECTID" => $novoId,
                    "COD_SIG" => "",
                    "IDTIPO" => "",
                    "TPRS_ID" => "",
                    "TPRS_DESC" => "Ponto adicionado pelo administrador",
                    "FRE_AB" => "",
                    "TOP_MOD_1" => $tipoEquipamento,
                    "PRSL_X" => "",
                    "PRSL_Y" => "",
                    "PRSL_LOCAL" => $localNome,
                    "PRODUTOR" => "n.a.",
                    "SE_ANNO_CAD_DATA" => "",
                    "GlobalID" => ""
                ]
            ];

            file_put_contents(
                $jsonPath,
                json_encode($geo, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
            );

            /* 3) Enviar email de aviso */
            $destinatario = "andreventuraoriginal@gmail.com"; // troca pelo email real
            $assunto = "Novo ponto de recolha adicionado";
            $mensagem = "Foi adicionado um novo ponto de recolha.\n\n" .
                        "Local: $localNome\n" .
                        "Tipo: $tipoEquipamento\n" .
                        "Latitude: $latitude\n" .
                        "Longitude: $longitude";

            @mail($destinatario, $assunto, $mensagem);

            $sucesso = "Ponto adicionado com sucesso! O mapa e o email foram atualizados.";
        } catch (Exception $e) {
            $erro = "Erro ao adicionar o ponto: " . $e->getMessage();
        }
    }
}

/* ===== APAGAR PONTO DA BD ===== */
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM pontos_recolha WHERE id_pontos = ?");
    $stmt->execute([$delId]);

    header("Location: Painel_Admin.php");
    exit();
}

/* ===== LISTAR PONTOS DA BD ===== */
$stmt = $pdo->query("
    SELECT id_pontos, latitude, longitude, local_nome
    FROM pontos_recolha
    ORDER BY id_pontos ASC
");
$pontos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Painel de Administração</title>
    <link rel="stylesheet" href="CSS.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="admin-body">

<div class="admin-container">
    <header class="admin-header">
        <div class="admin-title">Painel de Administração</div>
        <div class="admin-user">
            <span class="user-badge">
                <?= htmlspecialchars($_SESSION['user']['username'] ?? 'Admin') ?>
            </span>
            <a href="index.php" class="nav-btn">Início</a>
            <a href="Mapa.php" class="nav-btn">Mapa</a>
            <a href="logout.php" class="nav-btn">Sair</a>
        </div>
    </header>

    <main class="admin-main">
        <section class="admin-card">
            <h2 class="admin-section-title">Adicionar ponto de recolha</h2>

            <?php if ($erro): ?>
                <div class="alert-error"><?= htmlspecialchars($erro) ?></div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
                <div class="alert-success"><?= htmlspecialchars($sucesso) ?></div>
            <?php endif; ?>

            <form method="post" class="admin-form">
                <div class="form-group">
                    <label for="latitude">Latitude</label>
                    <input type="text" name="latitude" id="latitude" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="longitude">Longitude</label>
                    <input type="text" name="longitude" id="longitude" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="local_nome">Nome / descrição do local</label>
                    <input type="text" name="local_nome" id="local_nome" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="top_mod_1">Tipo de eletrónico</label>
                    <input type="text" name="top_mod_1" id="top_mod_1" class="form-control" required>
                </div>

                <button type="submit" name="adicionar_ponto" class="btn-primary">
                    Guardar ponto
                </button>
            </form>
        </section>

        <section class="admin-card">
            <h2 class="admin-section-title">Pontos adicionados na base de dados</h2>

            <div class="admin-table-wrapper">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                            <th>Local</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($pontos): ?>
                            <?php foreach ($pontos as $p): ?>
                                <tr>
                                    <td><?= htmlspecialchars($p['id_pontos']) ?></td>
                                    <td><?= htmlspecialchars($p['latitude']) ?></td>
                                    <td><?= htmlspecialchars($p['longitude']) ?></td>
                                    <td><?= htmlspecialchars($p['local_nome']) ?></td>
                                    <td>
                                        <a class="admin-link-danger"
                                           href="?delete=<?= urlencode($p['id_pontos']) ?>"
                                           onclick="return confirm('Tem a certeza que deseja apagar este ponto?');">
                                            Apagar
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="admin-empty">
                                    Ainda não existem pontos registados.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>

</body>
</html>