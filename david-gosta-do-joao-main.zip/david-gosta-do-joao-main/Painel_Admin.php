﻿<?php
session_start();
require "db.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die("Acesso negado");
}

// ➕ adicionar ponto
if (isset($_POST['adicionar'])) {
    $lat  = $_POST['latitude'];
    $lng  = $_POST['longitude'];
    $type = $_POST['type'];

    $coordinates = $lat . "," . $lng;

    $stmt = $pdo->prepare("INSERT INTO pontos_recolha (type, coordinates) VALUES (?, ?)");
    $stmt->execute([$type, $coordinates]);

    // ===== ENVIAR EMAIL A TODOS OS UTILIZADORES VERIFICADOS =====
    $stmtUsers = $pdo->prepare("SELECT email FROM utilizadores WHERE verify = 1");
    $stmtUsers->execute();
    $emails = $stmtUsers->fetchAll(PDO::FETCH_COLUMN);

    $assunto  = "Novo ponto de recolha adicionado";
    $mensagem = "Foi adicionado um novo ponto de recolha do tipo " . $type . " nas coordenadas " . $coordinates . ".";

    foreach ($emails as $email) {
        $email_arg    = escapeshellarg($email);
        $assunto_arg  = escapeshellarg($assunto);
        $mensagem_arg = escapeshellarg($mensagem);

        $comando = "python Email.py $email_arg $assunto_arg $mensagem_arg 2>&1";
        shell_exec($comando);
    }
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM pontos_recolha WHERE id_pontos = ?");
    $stmt->execute([$_GET['delete']]);
}

// 📦 listar
$stmt = $pdo->query("SELECT * FROM pontos_recolha");
$pontos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Painel Admin | ZeroLixo</title>
    <link rel="stylesheet" href="CSS.css">
</head>
<body class="admin-body">

<div class="admin-container">
    <header class="admin-header">
        <div class="admin-title">
            Painel de Administração
        </div>
        <div class="admin-user">
            <?php if (isset($_SESSION['user'])): ?>
                <span class="user-badge">
                    Olá, <?php echo htmlspecialchars($_SESSION['user']['username']); ?>
                </span>
            <?php endif; ?>
            <a href="index.php" class="nav-btn">Voltar ao site</a>
        </div>
    </header>

    <main class="admin-main">
        <section class="admin-card">
            <h2 class="admin-section-title">Adicionar ponto de recolha</h2>
            <form method="POST" class="admin-form">
                <div class="form-group">
                    <label for="latitude">Latitude</label>
                    <input type="text" id="latitude" name="latitude" required class="form-control">
                </div>

                <div class="form-group">
                    <label for="longitude">Longitude</label>
                    <input type="text" id="longitude" name="longitude" required class="form-control">
                </div>

                <div class="form-group">
                    <label for="type">Tipo de resíduo eletrónico</label>
                    <input type="text" id="type" name="type" placeholder="Ex.: Televisor, Pequenos EEE…" class="form-control">
                </div>

                <button name="adicionar" class="btn-primary">Adicionar ponto</button>
            </form>
        </section>

        <section class="admin-card">
            <h2 class="admin-section-title">Pontos de recolha</h2>

            <div class="admin-table-wrapper">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Coordenadas</th>
                            <th>Tipo</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pontos as $p): ?>
                        <tr>
                            <td><?= $p['id_pontos'] ?></td>
                            <td><?= htmlspecialchars($p['coordinates']) ?></td>
                            <td><?= htmlspecialchars($p['type']) ?></td>
                            <td>
                                <a href="?delete=<?= $p['id_pontos'] ?>" class="admin-link-danger">Apagar</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($pontos)): ?>
                        <tr>
                            <td colspan="4" class="admin-empty">Ainda não existem pontos registados.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>

</body>
</html>