<?php
session_start();
require "db.php";

$erro = "";
$sucesso = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $token_input = trim($_POST['token'] ?? '');

    if ($email === "" || $token_input === "") {
        $erro = "Preencha o email e o token.";
    } else {
        $stmt = $pdo->prepare(
            "SELECT id_utilizadores, token FROM utilizadores WHERE email = :email AND verify = 0"
        );
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            $erro = "Conta não encontrada ou já verificada.";
        } else {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $token_db = decryptAES($row['token']);

            if ($token_db === false) {
                $erro = "Erro ao ler o token guardado.";
            } else {
                $token_input = strtolower(trim($token_input));
                $token_db = strtolower(trim($token_db));

                if (hash_equals($token_db, $token_input)) {
                    $upd = $pdo->prepare(
                        "UPDATE utilizadores SET verify = 1 WHERE id_utilizadores = :id_utilizadores"
                    );
                    $upd->bindParam(':id_utilizadores', $row['id_utilizadores'], PDO::PARAM_INT);
                    $upd->execute();

                    $sucesso = "Conta verificada com sucesso! Já pode fazer login.";
                } else {
                    $erro = "Token incorreto.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Verificação | ZeroLixo</title>
    <link rel="stylesheet" href="CSS.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="auth-page">

<div class="purple-bg">
    <span class="verify-shape verify-shape-1"></span>
    <span class="verify-shape verify-shape-2"></span>
    <span class="verify-shape verify-shape-3"></span>
    <span class="verify-shape verify-shape-4"></span>
</div>

<div class="auth-card verification-card">
    <div class="info-card verification-box">
        <div class="verification-header">
            <div class="verification-icon">✓</div>
            <span class="highlight-text verification-heading">Verificação de conta</span>
            <p class="verification-text">
                Introduza o email e o token que recebeu para ativar a sua conta.
            </p>
        </div>

        <?php if ($erro): ?>
            <div class="alert-error"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <div class="alert-success"><?= htmlspecialchars($sucesso) ?></div>
            <a href="Login.php" class="btn-primary verification-btn-link">Ir para login</a>
        <?php else: ?>
            <form method="post" autocomplete="off">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Introduza o seu email"
                        required
                        class="form-control"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="token">Token de verificação</label>
                    <input
                        type="text"
                        id="token"
                        name="token"
                        placeholder="Token recebido por email"
                        required
                        class="form-control"
                        value="<?= htmlspecialchars($_POST['token'] ?? '') ?>"
                    >
                </div>

                <button type="submit" class="btn-primary">Verificar conta</button>
            </form>

            <p class="verification-footer">
                Já verificou a conta?
                <a href="Login.php" class="verification-link">Entrar</a>
            </p>
        <?php endif; ?>

        <div class="glow-line"></div>
    </div>
</div>

</body>
</html>