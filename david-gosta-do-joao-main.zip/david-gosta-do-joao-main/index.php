<?php
session_start();

if(isset($_POST['Botão_index_mapa'])){
    header("Location: Mapa.php");
    exit();
}
if(isset($_POST['Botão_index_registo'])){
    header("Location: registo.php");
    exit();
}
if(isset($_POST['Botão_index_login'])){
    header("Location: Login.php");
    exit();
}
if(isset($_POST['Botão_index_contactos'])){
    header("Location: contactos.php");
    exit();
}
if(isset($_POST['Botão_index_logout'])){
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS.css">
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <title>ZeroLixo</title>
</head>
<body>
    <table>
        <th class="site-logo">
            ZeroLixo
        </th>
        <td class="site-nav">
            <div class="container">
                <form method="post" action="" style="display:inline;">
                    <button type="submit" name="Botão_index_mapa" class="nav-btn">Mapa</button>
                    <button type="submit" name="Botão_index_registo" class="nav-btn">Registo</button>
                    <button type="submit" name="Botão_index_login" class="nav-btn">Login</button>
                    <button type="submit" name="Botão_index_contactos" class="nav-btn">Contactos</button>
                    <?php if (isset($_SESSION['user'])): ?>
                        <button type="submit" name="Botão_index_logout" class="nav-btn">Sair</button>
                    <?php endif; ?>
                </form>

                <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'): ?>
                    <a href="Painel_Admin.php" class="nav-btn">Dashboard</a>
                <?php endif; ?>

                <?php if (isset($_SESSION['user'])): ?>
                    <span class="user-badge">
                        Olá, <?php echo htmlspecialchars($_SESSION['user']['username']); ?>
                    </span>
                <?php endif; ?>
            </div>
        </td>
    </table>
    
    
    <h2 class="page-title">
        ZEROLIXO é um website que mostra os pontos de recolha e reciclagem em Lisboa, facilitando aos cidadãos saber onde depositar corretamente os resíduos. 
        O objetivo é promover a reciclagem e contribuir para uma cidade mais limpa e sustentável.
    </h2>

<footer>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p style="text-align: center;">&copy;2026 ZeroLixo. Todos os direitos reservados.</p>
</footer>

</