<?php
session_start();
require "db.php";

$erro = "";
$sucesso = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($username == "" || $email == "" || $password == "" || $role == "") {
        $erro = "Preencha todos os campos";
    } else {
        $stmt = $pdo->prepare("SELECT id_utilizadores FROM utilizadores WHERE username = :username OR email = :email");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        $token = bin2hex(random_bytes(4)); // 8 caracteres hex

        if ($stmt->rowCount() > 0) {
            $erro = "Este username ou email já existe";
        } else {
            $password_encriptada = encryptAES($password);

            if ($password_encriptada === false) {
                $erro = "Erro ao encriptar a password.";
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO utilizadores (username, email, password, role, token, verify)
                    VALUES (:username, :email, :password, :role, :token, 0)
                ");

                $stmt->bindParam(':username', $username, PDO::PARAM_STR);
                $stmt->bindParam(':email', $email, PDO::PARAM_STR);
                $stmt->bindParam(':password', $password_encriptada, PDO::PARAM_STR);
                $stmt->bindParam(':role', $role, PDO::PARAM_STR);
                $stmt->bindParam(':token', $token, PDO::PARAM_STR);
                $stmt->execute();

                $sucesso = "Conta criada com sucesso!";

                $email_arg = escapeshellarg($email);
                $token_arg = escapeshellarg($token);
                $comando = "python email.token.py $email_arg $token_arg 2>&1";
                $output = shell_exec($comando);

                header("Location: Verificacao.php");
                exit();
            }
        }
    }
}

if (isset($_POST['Botao_para_login'])) {
    header("Location: Login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Registo | Zero-lixo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
<link rel="stylesheet" href="CSS.css">
</head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}
.menu {
  float: left;
  width: 20%;
}
.menuitem {
  padding: 8px;
  margin-top: 7px;
  border-bottom: 1px solid #f1f1f1;
}
.main {
  float: left;
  width: 60%;
  padding: 0 20px;
  overflow: hidden;
}
.right {
  background-color: lightblue;
  float: left;
  width: 20%;
  padding: 10px 15px;
  margin-top: 7px;
}

@media only screen and (max-width:800px) {
  /* For tablets: */
  .main {
    width: 80%;
    padding: 0;
  }
  .right {
    width: 100%;
  }
}
@media only screen and (max-width:500px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width: 100%;
  }
}
</style>
</head>
</html>

<body class="auth-page">
<div class="mouse-ball"></div>
<div class="purple-bg">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>
<div class="containar_2">
    <div class="auth-card"> 

        <?php if ($erro): ?>
            <div class="alert-error"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <div class="alert-success"><?= htmlspecialchars($sucesso) ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <div class="info-card" style="width: 18rem;">
                    
                    <span class="material-symbols-outlined info-icon">
                    key
                    </span>
                    <label class="highlight-text">Registo</label>
                    <form method="post" autocomplete="off">
                        <p>
                        <input type="text" name="username" placeholder="Username" required class="form-control">
                        <p>
                        <input type="text" name="email" placeholder="email" required class="form-control">
                        <p>
                        <input type="password" name="password" placeholder="Password" required class="form-control">
                        <p>
                        
                        <select name="role" required class="form-select">
                            <option value="" disabled selected>Selecionar perfil</option>
                            <option value="cliente">Cliente</option>
                            <option value="admin">Admin</option>
                        </select>
                        <a href="login.php">
                        <br>
                        
                        <button type="submit" name="Botao_para_login" class="btn-primary">Registar</button>
                        </a>
                    </form>
                    <p style="margin-top:15px;">    
                        Já tem conta?
                        <a href="login.php">Entrar</a>
                    </p>
            </div>
        </div>
        </div>

        <div class="glow-line"></div>
    </div>
</div>

</body>
</html>