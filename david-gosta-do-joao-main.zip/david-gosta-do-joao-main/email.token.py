import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import sys

sender_email = "andreventuraoriginal@gmail.com"
password = "sapa mncy vbpe zylc"
receiver_email = sys.argv[1]
token =sys.argv[2]

msg = MIMEMultipart()
msg['From'] = sender_email
msg['To'] = receiver_email
msg['Subject'] = "Token de verificação - ZeroLixo" 
body = f"""O seu token de verificação é: {token}

Introduza este token na página de verificação para poder ativar a sua conta

Comprimentos equipa ZeroLixo"""
msg.attach(MIMEText(body, 'plain'))

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login(sender_email, password)

server.sendmail(sender_email, receiver_email, msg.as_string())
server.quit()

print("E-mail enviado com sucesso!")