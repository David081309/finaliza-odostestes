<?php
require "db.php";

$stmt = $pdo->query("
    SELECT id_pontos, OBJECTID, latitude, longitude, local_nome
    FROM pontos_recolha
    WHERE latitude IS NOT NULL AND longitude IS NOT NULL
");

$features = [];

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $features[] = [
        "type" => "Feature",
        "geometry" => [
            "type" => "Point",
            "coordinates" => [
                (float)$row["longitude"],
                (float)$row["latitude"]
            ]
        ],
        "properties" => [
            "id_pontos" => $row["id_pontos"],
            "OBJECTID" => $row["OBJECTID"],
            "name" => $row["local_nome"]
        ]
    ];
}

header("Content-Type: application/json; charset=utf-8");
echo json_encode([
    "type" => "FeatureCollection",
    "features" => $features
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>