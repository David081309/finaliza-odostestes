<?php 
require_once "M16";
$conn = new mysqli('localhost', 'root', '', 'm16');

$json = file_get_contents('pontos.json');
$data = json_decode($json, true);
if ($data && isset($data['features'])) {
    foreach ($data['features'] as $feature) {
        $objectid = $feature['properties']['OBJECTID'];
        $lat = $feature['geometry']['coordinates'][1];
        $lon = $feature['geometry']['coordinates'][0];
        $name = $feature['properties']['TPRS_DESC'];
        
        // Verificar se já existe
        $check = $conn->prepare("SELECT OBJECTID FROM locais WHERE OBJECTID = ?");
        $check->bind_param("i", $objectid);
        $check->execute();
        $check->store_result();
        if ($check->num_rows == 0) {
            // Inserir
            $insert = $conn->prepare("INSERT INTO locais (OBJECTID, latitude, longitude, local_nome) VALUES (?, ?, ?, ?)");
            $insert->bind_param("idds", $objectid, $lat, $lon, $name);
            $insert->execute();
            $insert->close();
        }
        $check->close();
    }
}

$resultado = $conn->query("SELECT OBJECTID, latitude, longitude, local_nome FROM locais");
$features = [];
while ($row = $resultado->fetch_assoc()) {
    $features[] = ['type' => 'Feature', 'geometry' => ['type' => 'Point', 'coordinates' => [(float) $row['longitude'], (float) $row['latitude']]], 'properties' => ['name' => $row['local_nome']]];
}
header('Content-Type: application/json');
echo json_encode(['type' => 'FeatureCollection', 'features' => $features]); ?>S