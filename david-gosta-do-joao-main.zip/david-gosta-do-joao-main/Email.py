import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import sys

sender_email = "andreventuraoriginal@gmail.com"
receiver_email = sys.argv[1]      # email vindo do formulário
assunto = sys.argv[2]             # assunto vindo do formulário
mensagem = sys.argv[3]            # mensagem escrita pelo utilizador

password = "sapa mncy vbpe zylc"

msg = MIMEMultipart()
msg['From'] = sender_email
msg['To'] = receiver_email
msg['Subject'] = assunto

body = mensagem
msg.attach(MIMEText(body, 'plain'))

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login(sender_email, password)

server.sendmail(sender_email, receiver_email, msg.as_string())
server.quit()

print("E-mail enviado com sucesso!")