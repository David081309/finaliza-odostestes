<!doctype html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mapa | ZeroLixo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin=""/>
    <link rel="stylesheet" href="CSS.css">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
  <body class="map-body">

    <div class="map-topbar">
      <div class="map-topbar-left">
        <a href="index.php" class="map-btn">Voltar ao Início</a>
        <a href="Painel_Admin.php" class="map-btn">Painel Admin</a>
      </div>
      <div class="map-topbar-right">
        <select id="filtro-tipo" class="map-select">
          <option value="">Todos os tipos de eletrónicos</option>
        </select>
      </div>
    </div>

    <div id="map"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>

    <script>
      var map = L.map('map').setView([38.743164, -9.132753], 11.5);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data © <a href="http://www.openstreetmap.org">OpenStreetMap</a>'
      }).addTo(map);

      var allFeaturesLayer;
      var allData;
      var tipoSelect = document.getElementById('filtro-tipo');

      var pontosManuais = [];

      fetch('pontos.json')
        .then(response => response.json())
        .then(data => {
          var featuresFicheiro = data.features || [];
          var todasFeatures = featuresFicheiro.concat(pontosManuais);

          allData = {
            type: 'FeatureCollection',
            features: todasFeatures
          };

          allFeaturesLayer = L.geoJSON(allData, {
            onEachFeature: function (feature, layer) {
              var props = feature.properties || {};
              var popupContent =
                (props.TOP_MOD_1 || 'Tipo de equipamento desconhecido') + "<br>" +
                (props.TPRS_DESC || '') + "<br>" +
                (props.PRSL_LOCAL || '');
              layer.bindPopup(popupContent);
            }
          }).addTo(map);

          var tiposSet = new Set();
          todasFeatures.forEach(function(f) {
            if (f.properties && f.properties.TOP_MOD_1) {
              tiposSet.add(f.properties.TOP_MOD_1);
            }
          });

          Array.from(tiposSet).sort().forEach(function(tipo) {
            var opt = document.createElement('option');
            opt.value = tipo;
            opt.textContent = tipo;
            tipoSelect.appendChild(opt);
          });
        })
        .catch(function(err) {
          console.error("Erro ao ler pontos.json:", err);
        });

      tipoSelect.addEventListener('change', function() {
        var valor = this.value;

        if (allFeaturesLayer) {
          map.removeLayer(allFeaturesLayer);
        }

        var baseOptions = {
          onEachFeature: function (feature, layer) {
            var props = feature.properties || {};
            var popupContent =
              (props.TOP_MOD_1 || 'Tipo de equipamento desconhecido') + "<br>" +
              (props.TPRS_DESC || '') + "<br>" +
              (props.PRSL_LOCAL || '');
            layer.bindPopup(popupContent);
          }
        };

        if (!valor) {
          allFeaturesLayer = L.geoJSON(allData, baseOptions).addTo(map);
          return;
        }

        var filtrado = {
          type: 'FeatureCollection',
          features: (allData.features || []).filter(function(f) {
            return f.properties && f.properties.TOP_MOD_1 === valor;
          })
        };

        allFeaturesLayer = L.geoJSON(filtrado, baseOptions).addTo(map);
      });
    </script>
  </body>
</html>