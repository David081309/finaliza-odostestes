<!doctype html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mapa | ZeroLixo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
    <link rel="stylesheet" href="CSS.css">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
  <body class="map-body">

    <!-- Barra de topo: voltar + filtro tipo eletrónico -->
    <div class="map-topbar">
      <div class="map-topbar-left">
        <a href="index.php" class="map-btn">Voltar ao Início</a>
      </div>
      <div class="map-topbar-right">
        <select id="filtro-tipo" class="map-select">
          <option value="">Todos os tipos de eletrónicos</option>
          <!-- opções preenchidas em JS a partir de TOP_MOD_1 -->
        </select>
      </div>
    </div>

    <!-- Mapa ocupa todo o ecrã restante -->
    <div id="map"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

    <script>
      // 1) Inicializar mapa
      var map = L.map('map').setView([38.743164, -9.132753], 11.5);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data © <a href="http://www.openstreetmap.org">OpenStreetMap</a>'
      }).addTo(map);

      var allFeaturesLayer;
      var allData;
      var tipoSelect = document.getElementById('filtro-tipo');

      // 2) PONTOS EXTRA MANUAIS (se quiseres acrescentar alguns no código)
      //    Aqui podes adicionar pontos específicos, além dos que vêm do ficheiro.
      var pontosManuais = [
        /*
        {
          "type": "Feature",
          "properties": {
            "TOP_MOD_1": "Televisor",
            "TPRS_DESC": "Ponto de recolha de EEE",
            "PRSL_LOCAL": "Centro de recolha exemplo"
          },
          "geometry": {
            "type": "Point",
            "coordinates": [-9.15, 38.73] // longitude, latitude
          }
        }
        */
      ];

      // 3) Carregar dados do ficheiro + juntar com os manuais
      fetch('pontos.json')
        .then(response => response.json())
        .then(data => {
          // Garantir que existe array de features
          var featuresFicheiro = data.features || [];
          var todasFeatures = featuresFicheiro.concat(pontosManuais);

          allData = {
            type: 'FeatureCollection',
            features: todasFeatures
          };

          // Criar layer com todos os pontos
          allFeaturesLayer = L.geoJSON(allData, {
            onEachFeature: function (feature, layer) {
              var props = feature.properties || {};
              var popupContent =
                (props.TOP_MOD_1 || 'Tipo de equipamento desconhecido') + "<br>" +
                (props.TPRS_DESC || '') + "<br>" +
                (props.PRSL_LOCAL || '');
              layer.bindPopup(popupContent);
            }
          }).addTo(map);

          // Preencher filtro com valores únicos de TOP_MOD_1 (tipos de eletrónicos)
          var tiposSet = new Set();
          todasFeatures.forEach(function(f) {
            if (f.properties && f.properties.TOP_MOD_1) {
              tiposSet.add(f.properties.TOP_MOD_1);
            }
          });

          Array.from(tiposSet).sort().forEach(function(tipo) {
            var opt = document.createElement('option');
            opt.value = tipo;
            opt.textContent = tipo;
            tipoSelect.appendChild(opt);
          });
        });

      // 4) Filtro por tipo de eletrónico (TOP_MOD_1)
      tipoSelect.addEventListener('change', function() {
        var valor = this.value;

        if (allFeaturesLayer) {
          map.removeLayer(allFeaturesLayer);
        }

        var baseOptions = {
          onEachFeature: function (feature, layer) {
            var props = feature.properties || {};
            var popupContent =
              (props.TOP_MOD_1 || 'Tipo de equipamento desconhecido') + "<br>" +
              (props.TPRS_DESC || '') + "<br>" +
              (props.PRSL_LOCAL || '');
            layer.bindPopup(popupContent);
          }
        };

        if (!valor) {
          // Todos os tipos
          allFeaturesLayer = L.geoJSON(allData, baseOptions).addTo(map);
          return;
        }

        // Apenas tipo selecionado (televisor, pequeno eletrodoméstico, etc.)
        var filtrado = {
          type: 'FeatureCollection',
          features: (allData.features || []).filter(function(f) {
            return f.properties && f.properties.TOP_MOD_1 === valor;
          })
        };

        allFeaturesLayer = L.geoJSON(filtrado, baseOptions).addTo(map);
      });
    </script>
  </body>
</html>