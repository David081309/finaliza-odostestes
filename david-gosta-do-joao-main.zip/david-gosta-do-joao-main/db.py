import mysql.connector

DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "M16"


def inicializar_bd():
    cnx = mysql.connector.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD)
    cur = cnx.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
    cnx.commit()
    cnx.database = DB_NAME

    cur.execute("""
        CREATE TABLE IF NOT EXISTS utilizadores (
                id_utilizadores INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50),
                password VARCHAR(255),
                email VARCHAR(255),
                role ENUM('cliente','admin'),
                token VARCHAR (10),
                verify TINYINT (1) DEFAULT (0) NOT NULL
                )  
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pontos_recolha (
                id_pontos INT AUTO_INCREMENT PRIMARY KEY,
                latitude DOUBLE NULL,
                longitude DOUBLE NULL,
                local_nome VARCHAR(255) NULL,
                type VARCHAR(255) NULL,
                geometry VARCHAR(255) NULL,
                coordinates FLOAT NULL,
                OBJECTID INT NULL,
                COD_SIG INT NULL,
                IDTIPO INT NULL,
                TPRS_ID INT NULL,
                TPRS_DESC VARCHAR(255) NULL,
                FRE_AB VARCHAR(255) NULL,
                TOP_MOD_1 VARCHAR(255) NULL,
                PRSL_X INT NULL,
                PRSL_Y INT NULL,
                PRSL_LOCAL VARCHAR(255) NULL,
                PRODUTOR VARCHAR(255) NULL,
                SE_ANNO_CAD_DATA VARCHAR(255) NULL,
                GlobalID VARCHAR(255) NULL
        )
    """)

    
    

    cnx.commit()
    cur.close()
    cnx.close()
inicializar_bd()


