<?php
$host = "localhost";
$dbname = "M16";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

/* ===== AES PARA PASSWORD ===== */
const AES_KEY = '12345678901234567890123456789012';
const AES_CIPHER = 'AES-256-CBC';

function encryptAES($plaintext) {
    $ivLength = openssl_cipher_iv_length(AES_CIPHER);
    $iv = random_bytes($ivLength);

    $encrypted = openssl_encrypt($plaintext, AES_CIPHER, AES_KEY, OPENSSL_RAW_DATA, $iv);

    if ($encrypted === false) {
        return false;
    }

    return base64_encode($iv . $encrypted);
}

function decryptAES($ciphertextBase64) {
    if (empty($ciphertextBase64)) {
        return false;
    }

    $data = base64_decode($ciphertextBase64, true);
    if ($data === false) {
        return false;
    }

    $ivLength = openssl_cipher_iv_length(AES_CIPHER);

    if (strlen($data) < $ivLength) {
        return false;
    }

    $iv = substr($data, 0, $ivLength);
    $encrypted = substr($data, $ivLength);

    if (strlen($iv) !== $ivLength) {
        return false;
    }

    return openssl_decrypt($encrypted, AES_CIPHER, AES_KEY, OPENSSL_RAW_DATA, $iv);
}
?>