<?php
session_start();
require "db.php";

$erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($username == "" || $email == "" || $password == "" || $role == "") {
        $erro = "Preencha todos os campos";
    } else {
        $stmt = $pdo->prepare(
            "SELECT * FROM utilizadores WHERE username = ? AND email = ? AND role = ? AND verify = 1"
        );
        $stmt->execute([$username, $email, $role]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $password_guardada = decryptAES($user['password']);

            if ($password_guardada !== false && hash_equals($password_guardada, $password)) {
                $_SESSION['user'] = $user;

                if ($user['role'] === 'admin') {
                    header("Location: Painel_Admin.php");
                } else {
                    header("Location: index.php");
                }
                exit;
            } else {
                $erro = "Credenciais ou perfil inválidos";
            }
        } else {
            $erro = "Credenciais ou perfil inválidos";
        }
    }
}

if (isset($_POST['Botao_para_index'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Login | ZeroLixo</title>
<link rel="stylesheet" href="CSS.css">
</head>

<body class="auth-page">

<div class="mouse-ball"></div>

<div class="purple-bg">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>

<div class="auth-card login-glass ultra">
    <h1 class="highlight-text">Vidros</h1>
    <p style="margin-bottom: 14px;">Gestão de vidro reciclado</p>

    <?php if ($erro): ?>
        <div class="alert-error"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <input type="text" name="username" placeholder="Username" required autofocus class="form-control">
        <input type="text" name="email" placeholder="email" required class="form-control">
        <input type="password" name="password" placeholder="Password" required class="form-control">

        <select name="role" required class="form-select">
            <option value="" disabled selected>Selecionar perfil</option>
            <option value="cliente">Cliente</option>
            <option value="admin">Admin</option>
        </select>

        <button type="submit" class="btn-primary">Entrar</button>
    </form>

</html>